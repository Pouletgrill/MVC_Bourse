﻿namespace WindowsFormsApplication1
{
   partial class Form1
   {
      /// <summary>
      /// Variable nécessaire au concepteur.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// Nettoyage des ressources utilisées.
      /// </summary>
      /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
      protected override void Dispose(bool disposing)
      {
         if (disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Code généré par le Concepteur Windows Form

      /// <summary>
      /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
      /// le contenu de cette méthode avec l'éditeur de code.
      /// </summary>
      private void InitializeComponent()
      {
         this.button1 = new System.Windows.Forms.Button();
         this.label1 = new System.Windows.Forms.Label();
         this.label2 = new System.Windows.Forms.Label();
         this.label3 = new System.Windows.Forms.Label();
         this.LB_Prix_Goo = new System.Windows.Forms.Label();
         this.label5 = new System.Windows.Forms.Label();
         this.LB_Prix_Yahoo = new System.Windows.Forms.Label();
         this.SuspendLayout();
         // 
         // button1
         // 
         this.button1.Location = new System.Drawing.Point(94, 49);
         this.button1.Name = "button1";
         this.button1.Size = new System.Drawing.Size(75, 59);
         this.button1.TabIndex = 0;
         this.button1.Text = "button1";
         this.button1.UseVisualStyleBackColor = true;
         this.button1.Click += new System.EventHandler(this.button1_Click);
         // 
         // label1
         // 
         this.label1.AutoSize = true;
         this.label1.Location = new System.Drawing.Point(105, 158);
         this.label1.Name = "label1";
         this.label1.Size = new System.Drawing.Size(35, 13);
         this.label1.TabIndex = 1;
         this.label1.Text = "label1";
         // 
         // label2
         // 
         this.label2.AutoSize = true;
         this.label2.Location = new System.Drawing.Point(29, 158);
         this.label2.Name = "label2";
         this.label2.Size = new System.Drawing.Size(70, 13);
         this.label2.TabIndex = 2;
         this.label2.Text = "MICROSOFT";
         // 
         // label3
         // 
         this.label3.AutoSize = true;
         this.label3.Location = new System.Drawing.Point(29, 171);
         this.label3.Name = "label3";
         this.label3.Size = new System.Drawing.Size(41, 13);
         this.label3.TabIndex = 4;
         this.label3.Text = "Google";
         // 
         // LB_Prix_Goo
         // 
         this.LB_Prix_Goo.AutoSize = true;
         this.LB_Prix_Goo.Location = new System.Drawing.Point(105, 171);
         this.LB_Prix_Goo.Name = "LB_Prix_Goo";
         this.LB_Prix_Goo.Size = new System.Drawing.Size(35, 13);
         this.LB_Prix_Goo.TabIndex = 3;
         this.LB_Prix_Goo.Text = "label4";
         // 
         // label5
         // 
         this.label5.AutoSize = true;
         this.label5.Location = new System.Drawing.Point(29, 184);
         this.label5.Name = "label5";
         this.label5.Size = new System.Drawing.Size(38, 13);
         this.label5.TabIndex = 6;
         this.label5.Text = "Yahoo";
         // 
         // LB_Prix_Yahoo
         // 
         this.LB_Prix_Yahoo.AutoSize = true;
         this.LB_Prix_Yahoo.Location = new System.Drawing.Point(105, 184);
         this.LB_Prix_Yahoo.Name = "LB_Prix_Yahoo";
         this.LB_Prix_Yahoo.Size = new System.Drawing.Size(35, 13);
         this.LB_Prix_Yahoo.TabIndex = 5;
         this.LB_Prix_Yahoo.Text = "label6";
         // 
         // Form1
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.ClientSize = new System.Drawing.Size(284, 262);
         this.Controls.Add(this.label5);
         this.Controls.Add(this.LB_Prix_Yahoo);
         this.Controls.Add(this.label3);
         this.Controls.Add(this.LB_Prix_Goo);
         this.Controls.Add(this.label2);
         this.Controls.Add(this.label1);
         this.Controls.Add(this.button1);
         this.Name = "Form1";
         this.Text = "Form1";
         this.ResumeLayout(false);
         this.PerformLayout();

      }

      #endregion

      private System.Windows.Forms.Button button1;
      private System.Windows.Forms.Label label1;
      private System.Windows.Forms.Label label2;
      private System.Windows.Forms.Label label3;
      private System.Windows.Forms.Label LB_Prix_Goo;
      private System.Windows.Forms.Label label5;
      private System.Windows.Forms.Label LB_Prix_Yahoo;
   }
}

